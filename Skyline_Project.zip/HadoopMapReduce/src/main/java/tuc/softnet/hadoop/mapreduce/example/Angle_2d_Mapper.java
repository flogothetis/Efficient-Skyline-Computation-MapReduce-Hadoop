package tuc.softnet.hadoop.mapreduce.example;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class Angle_2d_Mapper extends MapReduceBase implements Mapper<LongWritable, Text, IntWritable, ArrayWritable> {
	public float partitions;
	
//member variables 	
	private static int counter =0 ;
 //Init parameters
	  public void configure(JobConf job) {
		  partitions  = Float.parseFloat(job.get("partitions"));
		  System.out.println(partitions);
	   }
	  
//MApper	  
public void map(LongWritable key, Text value,
		OutputCollector<IntWritable, ArrayWritable> collector, Reporter reporter)
		throws IOException {
	
	 float degrees = (float) (90.0 /partitions);
	 String[] values=null;

		
		values= value.toString().split((" , "));
		
		if(!( values[0].equals("ApartmentId"))){
	    if(values.length!=4) 
	    {
	    	System.out.println("Something is wrong with input file");
	    	
	    }
	   

	    // Compute φ1 and φ2
	    double deg=Math.toDegrees(Math.atan((Double.parseDouble(values[2]))/(Double.parseDouble(values[1]))));
	    double part=deg/degrees;
	    
	    collector.collect(new IntWritable((int) Math.ceil(part)),new TextArrayWritable(values));
		}

}




	
}
