package tuc.softnet.hadoop.mapreduce.example;

public class Angle_Partition_3d {

	public double p1,p3,p4 ;
	double p2;
	
	
	
	
}
