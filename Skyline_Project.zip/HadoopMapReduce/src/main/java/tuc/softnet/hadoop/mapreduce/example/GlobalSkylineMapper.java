package tuc.softnet.hadoop.mapreduce.example;

import java.io.IOException;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class GlobalSkylineMapper extends MapReduceBase implements Mapper<LongWritable, Text, IntWritable, ArrayWritable> {

	public void map(LongWritable key, Text value,
			OutputCollector<IntWritable, ArrayWritable> collector,
			Reporter reporter) throws IOException {
				// TODO Auto-generated method stub
		String[] values= value.toString().split((","));
		TextArrayWritable s1=new TextArrayWritable(values);
		String [] values2 =s1.toString().split(",");
		
  
	  for(int i=0;i<values.length;i++){
			values2[i]=values2[i].trim();
		}
	
	//write <key,value> pairs to Group by reducer ( only a reducer )
	collector.collect(new IntWritable(0),new TextArrayWritable(values2));		
		
		
		
	} 

	
	
	//At the end of the Task

	
}
