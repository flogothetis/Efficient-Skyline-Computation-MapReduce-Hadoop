package tuc.softnet.hadoop.mapreduce.example;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.util.Date;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RunningJob;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleOutputs;
import org.mortbay.log.Log;


public class Main_class {
	 static Configuration conf ;
	 static Path inputPath ;
	 static Path outputPath ;
	 static JobConf job ;
	static  RunningJob runningJob;
	public static int  partitions =0;
public static void main(String[] args) throws Exception {
	Log.info("****************************************");
	Log.info("@Author : Logothetis Fragkoulis ");
	Log.info("Advanced Databases  ");
	long startTime = System.currentTimeMillis();
	long elapsedTime = 0L;
	
	if(Integer.parseInt(args[3])<1 ||  Integer.parseInt(args[3])>10   )
	{
		Log.info("Wrong Instruction");
		return ;
	}
	if ( args[4].equals("random"))
	{
		 Log.info("random ---------- ");
     Random_Skyline(Integer.parseInt(args[3]),args[1],args[2]);
    
	}
else if(args[4].equals("angle") )
{
	if(args[5].equals("2d"))
	{
		Log.info("angle 2d-------- ");
		Angle_2d(Integer.parseInt(args[3]),args[1],args[2]);
		
	}
	else if(args[5].equals("3d")){
		Log.info("angle 3d-------- ");
		Angle_3d(Integer.parseInt(args[3]),args[1],args[2]);
		
	}
	else {
		Log.info("Wrong Instruction");
		return ;
	}
}
else 
{
	Log.info("Wrong Instruction");
	return ;
}


	
	 elapsedTime = System.currentTimeMillis() - startTime;
	 Log.info("Timer is :"+	 elapsedTime);
	
}

public static void Random_Skyline(int partitions, String args, String args2) throws IOException{
	 conf = new Configuration();
	 String input ="hdfs://localhost:9000/input/"+args ;
	 String output = "hdfs://localhost:9000/help";
	  inputPath = new Path(input);
	  outputPath = new Path(output);

		
	  job = new JobConf(conf, Main_class.class);
	 job.setJarByClass(Main_class.class);
	 job.setInt("partitions", partitions );
	 //conf.set("mapred.textoutputformat.separator", " , ");
	 job.setJobName("1Job");
   	FileInputFormat.setInputPaths(job, inputPath);
	 FileOutputFormat.setOutputPath(job, outputPath);
	 job.setOutputKeyClass(Text.class);
	 job.setOutputValueClass(Text.class);
	 job.setOutputFormat(TextOutputFormat.class);
	 job.setMapOutputKeyClass(IntWritable.class);
	 job.setMapOutputValueClass(TextArrayWritable.class);
	
	 job.setMapperClass(SkylineMapper.class);
	 job.setNumReduceTasks(5);
	 job.setReducerClass(SkylineReducer.class);
	 FileSystem hdfs = FileSystem.get(URI.create("hdfs://localhost:9000"), conf);
	 if (hdfs.exists(outputPath))
	 hdfs.delete(outputPath, true);
	 runningJob = JobClient.runJob(job);
	if(runningJob.isComplete()){
	 System.out.println("job.isSuccessfull: " + runningJob.isComplete());
	 Global_Skyline_2d(args2);
	 
	
}
	

}



public static void Global_Skyline_2d(String args2) throws IOException
{
	 conf = new Configuration();
	  inputPath = new Path("hdfs://localhost:9000/help");
	  outputPath = new Path("hdfs://localhost:9000/output");
	
	  job = new JobConf(conf, Main_class.class);
	 job.setJarByClass(Main_class.class);
	
	 job.setJobName("2Job");
	 FileInputFormat.setInputPaths(job, inputPath);
	 FileOutputFormat.setOutputPath(job, outputPath);
	 job.setOutputKeyClass(Text.class);
	 job.setOutputValueClass(Text.class);
	 
	 job.setOutputFormat(TextOutputFormat.class);
	 job.setInputFormat(TextInputFormat.class);
	 job.setMapOutputKeyClass(IntWritable.class);
	 job.setMapOutputValueClass(TextArrayWritable.class);

	 job.setMapperClass(GlobalSkylineMapper.class);
	 job.setReducerClass(SkylineReducer.class);
	 FileSystem hdfs = FileSystem.get(URI.create("hdfs://localhost:9000"), conf);
	
	 if (hdfs.exists(outputPath))
	 hdfs.delete(outputPath, true);
	 runningJob = JobClient.runJob(job);
	 if(runningJob.isComplete()){
		 System.out.println("job.isSuccessfull: " + runningJob.isComplete());
	 }
	 
	String dest= "hdfs://localhost:9000/output/"+args2;
	 
	 hdfs.rename(new Path("hdfs://localhost:9000/output/part-00000"), new Path(dest));
	 	
}


public static void Global_Skyline_3d(String args2) throws IOException
{
	 conf = new Configuration();
	  inputPath = new Path("hdfs://localhost:9000/help");
	  outputPath = new Path("hdfs://localhost:9000/output");
	  job = new JobConf(conf, Main_class.class);
	 job.setJarByClass(Main_class.class);
	
	 job.setJobName("3Job");
	 FileInputFormat.setInputPaths(job, inputPath);
	 FileOutputFormat.setOutputPath(job, outputPath);
	 job.setOutputKeyClass(Text.class);
	 job.setOutputValueClass(Text.class);
	 job.setOutputFormat(TextOutputFormat.class);
	 job.setInputFormat(TextInputFormat.class);
	 job.setMapOutputKeyClass(IntWritable.class);
	 job.setMapOutputValueClass(TextArrayWritable.class);

	 job.setMapperClass(GlobalSkylineMapper.class);
	 job.setReducerClass(Reducer_3d.class);
	 FileSystem hdfs = FileSystem.get(URI.create("hdfs://localhost:9000"), conf);
	 if (hdfs.exists(outputPath))
	 hdfs.delete(outputPath, true);
	 runningJob = JobClient.runJob(job);
	 if(runningJob.isComplete()){
		 System.out.println("job.isSuccessfull: " + runningJob.isComplete());
	 }
	
	 

		String dest= "hdfs://localhost:9000/output/"+args2;
		 
		 hdfs.rename(new Path("hdfs://localhost:9000/output/part-00000"), new Path(dest));

}




public static void Angle_3d(int partitions, String args, String args2) throws IOException{
	 conf = new Configuration();
	 String input ="hdfs://localhost:9000/input/"+args ;
	 String output = "hdfs://localhost:9000/help";
	  inputPath = new Path(input);
	  outputPath = new Path(output);
	  job = new JobConf(conf, Main_class.class);
	 job.setJarByClass(Main_class.class);
	
	 job.setJobName("4Job");
	FileInputFormat.setInputPaths(job, inputPath);
	 FileOutputFormat.setOutputPath(job, outputPath);
	 job.setOutputKeyClass(Text.class);
	 job.setOutputValueClass(Text.class);
	 job.setOutputFormat(TextOutputFormat.class);
	 job.setMapOutputKeyClass(IntWritable.class);
	 job.setMapOutputValueClass(TextArrayWritable.class);
	
	 job.setMapperClass(Mapper_3d.class);
	 job.setNumReduceTasks(5);
	 job.setReducerClass(Reducer_3d.class);
	 FileSystem hdfs = FileSystem.get(URI.create("hdfs://localhost:9000"), conf);
	 if (hdfs.exists(outputPath))
	 hdfs.delete(outputPath, true);
	 runningJob = JobClient.runJob(job);
	if(runningJob.isComplete()){
	 System.out.println("job.isSuccessfull: " + runningJob.isComplete());
	 Global_Skyline_3d(args2);
	 							}
}




public static void Angle_2d(int partitions ,String args,String args2) throws IOException{
	 conf = new Configuration();
	 String input ="hdfs://localhost:9000/input/"+args;
	 String output = "hdfs://localhost:9000/help";
	  inputPath = new Path(input);
	  outputPath = new Path(output);
	  job = new JobConf(conf, Main_class.class);
	  
	 job.setJarByClass(Main_class.class);
	 job.setInt("partitions", partitions);
	 //conf.set("mapred.textoutputformat.separator", " , ");
	 job.setJobName("5Job");
	FileInputFormat.setInputPaths(job, inputPath);
	 FileOutputFormat.setOutputPath(job, outputPath);
	 job.setOutputKeyClass(Text.class);
	 job.setOutputValueClass(Text.class);
	 job.setOutputFormat(TextOutputFormat.class);
	 job.setMapOutputKeyClass(IntWritable.class);
	 job.setMapOutputValueClass(TextArrayWritable.class);
	 job.setNumReduceTasks(5);
	 job.setMapperClass(Angle_2d_Mapper.class);
	
	 job.setReducerClass(SkylineReducer.class);
	 FileSystem hdfs = FileSystem.get(URI.create("hdfs://localhost:9000"), conf);
	 if (hdfs.exists(outputPath))
	 hdfs.delete(outputPath, true);
	 runningJob = JobClient.runJob(job);
	if(runningJob.isComplete()){
	 System.out.println("job.isSuccessfull: " + runningJob.isComplete());
	 Global_Skyline_2d(args2);
	 
	
}
	
}


}


