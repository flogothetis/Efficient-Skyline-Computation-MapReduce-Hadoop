package tuc.softnet.hadoop.mapreduce.example;


import java.io.IOException;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class Mapper_3d extends MapReduceBase implements Mapper<LongWritable, Text, IntWritable, ArrayWritable> {
	
	private static int counter =0 ;
	public Angle_Partition_3d [] a = new Angle_Partition_3d[9];
	
	  public void configure(JobConf job) {
			fill_data();
	   }
	
	
	

	public void fill_data (){
		a[0]= new Angle_Partition_3d();
		a[0].p1=0;
		a[0].p2=  48.24;
		a[0].p3=0;
		a[0].p4=30;
		a[1]= new Angle_Partition_3d();
		a[1].p1=48.24;
		a[1].p2= 70.52;
		a[1].p3=0;
		a[1].p4=30;
		a[2]= new Angle_Partition_3d();
		a[2].p1=70.52;
		a[2].p2= 90;
		a[2].p3=0;
		a[2].p4=30;
		a[3]= new Angle_Partition_3d();
		a[3].p1=0;
		a[3].p2= 48.24;
		a[3].p3=30;
		a[3].p4=60;
		a[4]= new Angle_Partition_3d();
		a[4].p1=48.24;
		a[4].p2= 70.52;
		a[4].p3=30;
		a[4].p4=60;
		a[5]= new Angle_Partition_3d();
		a[5].p1=70.52;
		a[5].p2= 90;
		a[5].p3=30;
		a[5].p4=60;
		a[6]= new Angle_Partition_3d();
		a[6].p1=0;
		a[6].p2=48.24;
		a[6].p3=60;
		a[6].p4=90;
		a[7]= new Angle_Partition_3d();
		a[7].p1=48.24;
		a[7].p2=70.52;
		a[7].p3=60;
		a[7].p4=90;
		a[8]= new Angle_Partition_3d();
		a[8].p1=70.52;
		a[8].p2=90;
		a[8].p3=60;
		a[8].p4=90;
		
		
		
		
		
	}
	
	
	
	
	
	
public void map(LongWritable key, Text value,
		OutputCollector<IntWritable, ArrayWritable> collector, Reporter reporter)
		throws IOException {
	

	String[] values;
	values= value.toString().split((" , "));
	if(!( values[0].equals("ApartmentId")))
	
	{
		
		
	    if(values.length!=4) 
	    {
	    	System.out.println("Something is wrong with input file");
	    	
	    }
	   double h1 =Math.pow(Double.parseDouble(values[3]), 2);
	   double h2 =Math.pow(Double.parseDouble(values[2]), 2);
	   double h3= Math.sqrt(h1+h2);
	  double deg1=Math.toDegrees(Math.atan(h3/Double.parseDouble(values[1])));	 
	 double deg2=Math.toDegrees(Math.atan((Double.parseDouble(values[2]))/(Double.parseDouble(values[1]))));

	
	  int i ;
	  for( i=0; i<9;i++){
		  
		  if( deg1>=a[i].p1 && deg1<=a[i].p2 && deg2>= a[i].p3 && deg2<=a[i].p4)
		  {
			  
			  collector.collect(new IntWritable(i+1),new TextArrayWritable(values));
			  break ;
		  }
	  }
	  if( i==9)
	  {
		  System.out.println("Error"+deg1+ " "+deg2);
		  return ;
	  }
		  
	  }
	  

	
	
}
	
	public void  close (){
		
		System.out.println("End of Angle-Based 3d Mapper");
		
	}
	
}
