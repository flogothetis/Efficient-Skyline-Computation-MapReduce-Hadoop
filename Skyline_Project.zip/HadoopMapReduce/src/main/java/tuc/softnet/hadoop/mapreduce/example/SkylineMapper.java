package tuc.softnet.hadoop.mapreduce.example;
import java.io.IOException;
import java.util.Random;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.htrace.commons.logging.LogFactory;
import org.mortbay.log.Log;


public class SkylineMapper extends MapReduceBase implements Mapper<LongWritable, Text, IntWritable, ArrayWritable> {
	
	static  int x = 0;	
	private static int counter =0 ;
	public int partitions;
	
	  @Override
	  public void configure(JobConf job) {
		 partitions  = Integer.parseInt(job.get("partitions"));
		  System.out.println(partitions);
	   }
	
//Configuration conf = context.getConfiguration();
//String param = conf.get("test");

public void map(LongWritable key, Text value, OutputCollector<IntWritable, ArrayWritable> collector, Reporter reporter)
 throws IOException {
	//read the whole line of the input text 
	
	
	String[] values;
	values= value.toString().split((" , "));
	if(!( values[0].equals("ApartmentId")))
	{
		
		
	    if(values.length!=4) 
	    {
	    	System.out.println("Something is wrong with input file");
	    	
	    }

	    
//write <key,value> pairs to Group by reduce
	 
collector.collect(new IntWritable(Random_values()%partitions),new TextArrayWritable(values));




}
}
public int Random_values(){
	Random rand = new Random(); 
	int value2;
	
value2 = rand.nextInt();
	
return value2;
}
//At the end of the Task
public void close() {

    System.out.println("A Mapper Finished Succefully");

}

}

