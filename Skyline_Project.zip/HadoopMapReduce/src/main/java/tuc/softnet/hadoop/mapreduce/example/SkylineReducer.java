package tuc.softnet.hadoop.mapreduce.example;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.log4j.Logger;
import org.mortbay.log.Log;
public class SkylineReducer extends MapReduceBase implements Reducer<IntWritable, TextArrayWritable, Text,Text> {
	PrintWriter writer;
	
	

public void reduce(IntWritable key, Iterator<TextArrayWritable> values2, OutputCollector<Text, Text> outputCollector,
 Reporter reporter) throws IOException {

	
	TextArrayWritable tmp;
	  String  s ;
	  int counter=0;
	  int add_notice=0;
	  int only_remove=0;
	  int full_dominate=0;
	  String  write_string = null;
	  int i;
	  String [] s2;
		ArrayList<Integer> ap_id = new ArrayList<Integer>();
		ArrayList<Double>  price=new ArrayList<Double>();
		ArrayList<Double>  age=new ArrayList<Double>();
		ArrayList<Double>  distance=new ArrayList<Double>();
     while (values2.hasNext()) 
 {
    	 
	
    	
    
    	  tmp = values2.next();
    	  s= tmp.toString();
          s2=s.split(" , ");
        
        int ap=Integer.parseInt(s2[0]);
        double pr=Double.parseDouble(s2[1]);
        double ag=Double.parseDouble(s2[2]) ;
        double dist=Double.parseDouble(s2[3]) ;
       
        if( counter==0)
        {
        	  ap_id.add(ap);
              price.add(pr);
              age.add(ag);
              distance.add(dist);
            
              
        }
        
        else 
        {
        	
        	 i=0;
        	while( i<ap_id.size())
        	{
        		
        		if(pr == price.get(i) && ag== age.get(i)){
        			
        			add_notice=1;
        			i++;
        			
        			
        		}
        		else if( pr<= price.get(i) && ag<= age.get(i))
    			{
        			
    				ap_id.remove(i);
    				price.remove(i);
    				age.remove(i);
    				distance.remove(i);
    				add_notice=1;
    				full_dominate=1;
    			
    				
    			}
        		
        			else if(pr>=price.get(i) && ag>=age.get(i)){
        			
        				only_remove=1;
        				i++;
        			
        				
        			}
        			else if( pr< price.get(i) || ag< age.get(i))
        			{
        			
        				
        				add_notice=1;
        				i++;
        				
        		    }
        			
        			else{ i++;
        			
        			}
        			
        			
        	}
        	if(full_dominate==1){
        		ap_id.add(ap);
		        price.add(pr);
		        age.add(ag);
		        distance.add(dist);
		        add_notice=0;
		       
        	}
        	if (add_notice==1 && only_remove==0)
        	{
        		
        		ap_id.add(ap);
		        price.add(pr);
		        age.add(ag);
		        distance.add(dist);
		        
		        
		
        	}
        	
        	add_notice=0;
        	only_remove=0;
        	full_dominate=0;
        	
        	
        	
        }
    counter++;

 }
    //Write the results 
 	for( i=0;i<ap_id.size();i++)     {
		 write_string =", "+price.get(i).toString()+" , "+age.get(i).toString()+" , "+distance.get(i).toString();
		outputCollector.collect(new Text(ap_id.get(i).toString()),new Text(write_string));
	
		
	}


          
     }

       
  
	
}


