package tuc.softnet.hadoop.mapreduce.example;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.Text;

public class TextArrayWritable extends ArrayWritable {
    public TextArrayWritable() {
        super(Text.class);
    }

    public TextArrayWritable(String[] strings) {
        super(Text.class);
        Text[] texts = new Text[strings.length];
        for (int i = 0; i < strings.length; i++) {
            texts[i] = new Text(strings[i]);
        }
        
        set(texts);
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String s : super.toStrings())
        {
        	s.length();
            sb.append(s).append(" , ");
        }
        return sb.toString();
    }
    
  public String [] Trim(){
	String [] array = null;
	int i =0;
	  for (String s : super.toStrings())
      {
        array[i]=s;
      }
	return array;
  
  }
    
}
